"""cov_iter_drift — cov_iter_dro SOTA (114.76) + DRIFT-ADAPTIVE matching window.

Bottleneck (oracle decomp): packing is solved (PAR~1.01 with true load); the EP256
residual is next-window FORECASTING error on the non-stationary Mix·DS-R1 case. The
target mean is already drift-adapted (drift_router), but the EP256 MATCHING trajectories
(_build_covmatch) still use the FULL window -> on Mix the pairing is computed on a stale,
regime-blended covariance structure. Here we drift-GATE the matching window: per layer,
the same L1 drift weight a_l in [0,1] sets where the s=48 trajectory subsample starts.
Stationary (a~0) -> start=0 -> full window == byte-identical to cov_iter_dro (no regression
on the cases we win). Drifting (a~1) -> sample the RECENT sub-window -> the anti-correlation
pairing reflects the CURRENT regime, not the stale average. Closes the gap that target-side
drift adaptation left open. Replication-robustness + EP<=128 block path identical to SOTA.

--- cov_iter_dro — STACK both 6x winners: cov_iter EP256 min-peak matching (114.61)
+ dro robust replication sizing (114.32). Orthogonal: one sets WHERE the 2 EP256 slots
pair (min realized co-spike peak), the other HOW MANY copies each expert gets (mean +
KAPPA_REP*std worst-case, decoupled from the gentler placement risk). cov_dro already
showed +0.04 from this stack on cov_match; applying it to the stronger cov_iter base.

--- cov_iter — cov_match winner (114.35) + RICHER EP256 matching for the 6x budget.

cov_match's phase-fold pairing won at EP256 with a cheap O(n log n) 1D heuristic. With
the per-call budget extended to ~6x DS-EPLB, we can afford the REAL objective: greedily
match each light slot to the device whose fixed heavy partner MINIMIZES the resulting
realized peak max_t(heavy[t] + light[t]) over the subsampled window — i.e. directly
minimize co-spiking instead of approximating it with one principal axis. O(n_device^2 * s),
vectorized per step (this is the kind of richer EP256 placement that floored at 3x but
fits at 6x). Heavy slots (one per device) fixed by load; light slots assigned heaviest-
first. Feasible by construction -> no floor. EP<=128 byte-identical to SOTA.

--- cov_match — drift_router SOTA + EXPLICIT anti-correlation PAIRING at EP256.

NEW MECHANISM (the covariance lever, explicit & safe): at EP256 each device holds
exactly 2 slots, so placement IS a pairing problem and device load = sum of its two
slots. Realized PAR = max_t(slot_a[t]+slot_b[t]); pairing ANTI-correlated experts cuts
each device's realized peak (var(dev)=var(a)+var(b)+2cov(a,b)). We do this explicitly
but in O(n log n), fully vectorized (no O(E^2) python loop -> no floor risk): subsample
the window, find the dominant co-spiking temporal mode u via 5 power iterations, and
score each slot by its projection (phase) onto u. Then a 2D fold: split slots into a
heavy half and a light half by load (balances the MEAN, the classic min-max pairing),
and within the fold pair each heavy slot with a light slot of OPPOSITE phase (balances
the realized PEAK by anti-correlating). Distinct from spectral_cut (which feeds phase as
a soft column to the greedy); this does the hard matching the 2-slot regime actually is.
EP256 only (n_exp_per_dev==2; else falls back to scalar greedy == SOTA). Feasible by
construction -> no floor. EP<=128 byte-identical to SOTA.

--- original drift_router note ---

WHY (experiments/ceiling_decomp.py): with perfect foresight the SAME packer hits
PAR ~1.0-1.4 at every EP, so packing is solved. On STATIONARY data the trailing
mean is a great predictor (forecast gap only +0.03..+0.11) and the residual is
structural static-hold -> nothing to gain. But under NON-STATIONARITY (the Mix
dataset: a mixture whose hot set drifts), the trailing-1024 mean goes stale and
realized PAR explodes (drift stress: trailing PAR 1.6->4.4 while block-foresight
stays ~1.3). That excess is a FORECASTING failure, not packing -> recoverable by
weighting recent iterations when drift is present.

MECHANISM: per layer, measure drift = ||recent_mean - full_mean||_1 / ||full_mean||_1
(recent = last quarter of the given window). Blend the target toward recency by
that drift: adaptive_mean = (1-a)*full_mean + a*recent_mean, a = clip(GAMMA*drift,0,1).
On stationary data drift~0 -> a~0 -> adaptive_mean == full_mean == EXACTLY peakblock
(so we cannot regress the cases we already win). On Mix, a->1 -> lean recent and
track the new regime. Everything else (joint-peak, block columns, EP-gating, sticky
relabel, no-trade band, EP-adaptive lambda) is peakblock, unchanged.

Tunables (env): FB_TAU, FB_LAMBDA, FB_LAMBDA_HI, FB_STAY, FB_WINDOW, FB_BLOCKS,
FB_BLOCK_MAXDEV, FB_THETA, FB_PEAKFRAC, FB_DRIFT_GAMMA (recency gain, default 1.0),
FB_RECENT_FRAC (recent sub-window fraction, default 0.25).
"""
from __future__ import annotations

import os

import numpy as np

_w = os.environ.get("FB_WINDOW")
WINDOW = None if _w in (None, "", "all") else int(_w)
TAU = float(os.environ.get("FB_TAU", "0.2"))
LAMBDA = float(os.environ.get("FB_LAMBDA", "2.0"))
LAMBDA_HI = float(os.environ.get("FB_LAMBDA_HI", "1.5"))
STAY = float(os.environ.get("FB_STAY", "0.25"))
BLOCKS = int(os.environ.get("FB_BLOCKS", "6"))
BLOCK_MAXDEV = int(os.environ.get("FB_BLOCK_MAXDEV", "128"))
THETA = float(os.environ.get("FB_THETA", "0.5"))
PEAKFRAC = float(os.environ.get("FB_PEAKFRAC", "0.10"))
DRIFT_GAMMA = float(os.environ.get("FB_DRIFT_GAMMA", "1.0"))
RECENT_FRAC = float(os.environ.get("FB_RECENT_FRAC", "0.25"))
DRIFT_GATE = float(os.environ.get("FB_DRIFT_GATE", "0.20"))  # deadband: below this, full window (==SOTA)

_STATE: dict = {}


def _drift_weight(hotness, full_mean):
    """Per-layer L1 relative drift between the recent sub-window and the full window,
    clipped to [0,1]. Same statistic that gates _adaptive_mean; reused to gate the
    EP256 matching window. Returns (L,)."""
    T = hotness.shape[0]
    r = max(1, int(round(RECENT_FRAC * T)))
    if r >= T:
        return np.zeros(full_mean.shape[0])
    recent_mean = hotness[-r:].mean(axis=0)
    denom = np.abs(full_mean).sum(axis=1) + 1e-12
    drift = np.abs(recent_mean - full_mean).sum(axis=1) / denom
    return np.clip(DRIFT_GAMMA * drift, 0.0, 1.0)


def _adaptive_mean(hotness, full_mean):
    """Blend the full-window mean toward the recent sub-window, per layer, by the
    measured drift. Stationary -> returns full_mean unchanged (== peakblock)."""
    T = hotness.shape[0]
    r = max(1, int(round(RECENT_FRAC * T)))
    if r >= T:
        return full_mean
    recent_mean = hotness[-r:].mean(axis=0)               # (L, E)
    denom = np.abs(full_mean).sum(axis=1) + 1e-12         # (L,)
    drift = np.abs(recent_mean - full_mean).sum(axis=1) / denom   # (L,)
    a = np.clip(DRIFT_GAMMA * drift, 0.0, 1.0)[:, None]   # (L,1)
    return (1.0 - a) * full_mean + a * recent_mean


def reset():
    _STATE.clear()


def _peak_mean(hotness):
    T, L, E = hotness.shape
    p = max(1, int(round(PEAKFRAC * T)))
    total = hotness.sum(axis=2)
    peak_idx = np.argpartition(total, T - p, axis=0)[T - p:]
    l_idx = np.broadcast_to(np.arange(L), (p, L))
    peaked = hotness[peak_idx, l_idx, :]
    return peaked.mean(axis=0)


def _block_means_all(hotness, k):
    T = hotness.shape[0]
    if k <= 1 or T < k:
        return hotness.mean(axis=0)[:, :, None]
    idx = (np.arange(T) * k) // T
    L, E = hotness.shape[1], hotness.shape[2]
    out = np.zeros((L, E, k))
    counts = np.zeros(k)
    for j in range(k):
        m = idx == j
        counts[j] = m.sum()
        out[:, :, j] = hotness[m].sum(axis=0)
    out /= np.maximum(counts, 1.0)[None, None, :]
    return out


def _init_deploy_table(n_device, n_experts, slots):
    deploy = np.zeros((n_device, slots), dtype=np.int64)
    for d in range(n_device):
        for s in range(slots - 1):
            deploy[d, s] = (d * (slots - 1) + s) % n_experts
        deploy[d, -1] = deploy[d, -2]
    return deploy


KAPPA_REP = float(os.environ.get("FB_KAPPA_REP", "3.0"))  # robust replication confidence


def _replicas_and_order(weight, n_device, n_exp_per_dev, rep_weight=None):
    n_experts = weight.shape[0]
    n_slots = n_device * n_exp_per_dev
    rw = weight if rep_weight is None else rep_weight   # DRO robust replication target
    replicas = np.ones(n_experts, dtype=np.int64)
    for _ in range(n_slots - n_experts):
        replicas[int(np.argmax(rw / replicas))] += 1
    slot_expert = np.repeat(np.arange(n_experts), replicas)
    slot_weight = weight[slot_expert] / replicas[slot_expert]
    order = np.argsort(slot_weight, kind="stable")[::-1]
    return replicas, slot_expert, slot_weight, order


def _on_prev(prev, n_device, n_experts, stay_amt):
    if prev is None or stay_amt <= 0:
        return None
    on_prev = np.zeros((n_device, n_experts), dtype=bool)
    for d in range(n_device):
        for e2 in prev[d]:
            if e2 >= 0:
                on_prev[d, int(e2)] = True
    return on_prev


def _build_scalar(weight, n_device, n_exp_per_dev, prev=None, rep_weight=None):
    n_experts = weight.shape[0]
    replicas, slot_expert, slot_weight, order = _replicas_and_order(
        weight, n_device, n_exp_per_dev, rep_weight)
    deploy = np.full((n_device, n_exp_per_dev), -1, dtype=np.int64)
    dev_load = np.zeros(n_device)
    dev_count = np.zeros(n_device, dtype=np.int64)
    big = float(slot_weight.sum()) + 1.0
    stay_amt = STAY * (float(slot_weight.sum()) / max(n_device, 1))
    on_prev = _on_prev(prev, n_device, n_experts, stay_amt)
    for idx in order:
        e = int(slot_expert[idx])
        score = dev_load + np.where((deploy == e).any(axis=1), big, 0.0)
        if on_prev is not None:
            score = score - np.where(on_prev[:, e], stay_amt, 0.0)
        score[dev_count >= n_exp_per_dev] = np.inf
        d = int(np.argmin(score))
        deploy[d, int(dev_count[d])] = e
        dev_load[d] += slot_weight[idx]
        dev_count[d] += 1
    return deploy


def _build_covmatch(weight, hot_l, n_device, n_exp_per_dev, prev=None, n_sub=48,
                    rep_weight=None, drift_a=0.0):
    """Greedy min-realized-peak matching for the 2-slot (EP256) regime: heavy slots
    fixed one-per-device by load; each light slot (heaviest first) goes to the device
    whose heavy partner minimizes max_t(heavy[t]+light[t]) over the subsample. Directly
    minimizes co-spiking (the real objective), affordable under the 6x budget. Falls back
    to scalar greedy when n_exp_per_dev != 2."""
    if n_exp_per_dev != 2:
        return _build_scalar(weight, n_device, n_exp_per_dev, prev, rep_weight)
    replicas, slot_expert, slot_weight, order = _replicas_and_order(
        weight, n_device, n_exp_per_dev, rep_weight)
    T = hot_l.shape[0]
    s = min(n_sub, T)
    # DRIFT-ADAPTIVE matching window with a DEADBAND: below DRIFT_GATE the layer is
    # treated as stationary -> start=0 -> full window (byte-identical to cov_iter_dro,
    # so finite-sample drift noise on LmSys cannot regress us). Above the gate it ramps:
    # drifting (Mix) -> sample the RECENT sub-window so the pairing tracks the regime.
    a_eff = max(0.0, drift_a - DRIFT_GATE) / (1.0 - DRIFT_GATE)
    start = int(a_eff * max(0, T - s))
    ti = np.linspace(start, T - 1, s).astype(np.int64)
    sig = hot_l[ti][:, slot_expert] / replicas[slot_expert][None, :]   # (s, n_slots)
    by_w = np.argsort(slot_weight, kind="stable")[::-1]
    heavy = by_w[:n_device]                              # one heavy slot per device d
    light = by_w[n_device:]
    sig_h = sig[:, heavy]                                # (s, n_device) fixed heavy loads
    light_order = light[np.argsort(slot_weight[light], kind="stable")[::-1]]
    avail = np.ones(n_device, dtype=bool)
    assign = np.full(n_device, -1, dtype=np.int64)       # device -> light slot id
    for j in light_order:
        peaks = (sig_h + sig[:, j][:, None]).max(0)      # resulting realized peak per device
        peaks[~avail] = np.inf
        d = int(np.argmin(peaks))
        assign[d] = j
        avail[d] = False
    deploy = np.empty((n_device, 2), dtype=np.int64)
    deploy[:, 0] = slot_expert[heavy]
    deploy[:, 1] = slot_expert[assign]
    return deploy


def _build_block(weight, block_w, n_device, n_exp_per_dev, prev=None, rep_weight=None):
    n_experts = weight.shape[0]
    replicas, slot_expert, slot_weight, order = _replicas_and_order(
        weight, n_device, n_exp_per_dev, rep_weight)
    slot_block = block_w[slot_expert] / replicas[slot_expert][:, None]
    k = slot_block.shape[1]
    deploy = np.full((n_device, n_exp_per_dev), -1, dtype=np.int64)
    dev_block = np.zeros((n_device, k))
    dev_count = np.zeros(n_device, dtype=np.int64)
    big = float(slot_weight.sum()) + 1.0
    stay_amt = STAY * (float(slot_weight.sum()) / max(n_device, 1))
    on_prev = _on_prev(prev, n_device, n_experts, stay_amt)
    for idx in order:
        e = int(slot_expert[idx])
        score = (dev_block + slot_block[idx]).max(axis=1)
        score = score + np.where((deploy == e).any(axis=1), big, 0.0)
        if on_prev is not None:
            score = score - np.where(on_prev[:, e], stay_amt, 0.0)
        score[dev_count >= n_exp_per_dev] = np.inf
        d = int(np.argmin(score))
        deploy[d, int(dev_count[d])] = e
        dev_block[d] += slot_block[idx]
        dev_count[d] += 1
    return deploy


def _align(new, old, load):
    nd, sl = new.shape
    old_head = old[np.arange(nd), np.argmax(load[old], axis=1)]
    new_head = new[np.arange(nd), np.argmax(load[new], axis=1)]
    from_head: dict = {}
    for j in range(nd):
        from_head.setdefault(int(new_head[j]), []).append(j)
    assign = -np.ones(nd, dtype=np.int64)
    used = np.zeros(nd, dtype=bool)
    leftover_old = []
    for d in range(nd):
        lst = from_head.get(int(old_head[d]))
        if lst:
            j = lst.pop()
            assign[d] = j
            used[j] = True
        else:
            leftover_old.append(d)
    rem = [j for j in range(nd) if not used[j]]
    for d, j in zip(leftover_old, rem):
        assign[d] = j
    rows = new[assign]
    out = np.empty_like(rows)
    for d in range(nd):
        src = rows[d]
        oldrow = old[d]
        used_src = np.zeros(sl, dtype=bool)
        rowout = -np.ones(sl, dtype=np.int64)
        for s in range(sl):
            e = int(oldrow[s])
            for t in range(sl):
                if not used_src[t] and int(src[t]) == e:
                    rowout[s] = e
                    used_src[t] = True
                    break
        rem_src = [int(src[t]) for t in range(sl) if not used_src[t]]
        ri = 0
        for s in range(sl):
            if rowout[s] < 0:
                rowout[s] = rem_src[ri]
                ri += 1
        out[d] = rowout
    return out


def _par(load, deploy):
    cut = np.bincount(deploy.reshape(-1), minlength=load.shape[0])
    weights = load / cut
    loads = weights[deploy.reshape(-1)].reshape(deploy.shape).sum(-1)
    return float(loads.max() / loads.mean())


def rebalance(hotness, n_device, n_red_expert):
    hotness = np.asarray(hotness, dtype=np.float64)
    if WINDOW is not None:
        hotness = hotness[-WINDOW:]
    full_mean = hotness.mean(axis=0)
    # DRIFT-ADAPTIVE target: lean on recent iters when the window is non-stationary
    # (Mix); identical to full_mean when stationary (LmSys/ShareGPT/WildChat).
    mean = _adaptive_mean(hotness, full_mean)
    peak = _peak_mean(hotness) if THETA > 0 else mean
    place_w = (1.0 - THETA) * mean + THETA * peak
    lam = LAMBDA_HI if n_device >= 128 else LAMBDA
    std = hotness.std(axis=0)
    risk = place_w + lam * std if lam else place_w
    rep_w = place_w + KAPPA_REP * std   # DRO robust replication target (worst-case)
    drift_a = _drift_weight(hotness, full_mean)   # (L,) gate for the matching window
    n_layers, n_experts = mean.shape
    n_exp_per_dev = (n_experts + n_red_expert) // n_device

    use_block = n_device <= BLOCK_MAXDEV
    block_w = _block_means_all(hotness, BLOCKS) if use_block else None
    if use_block and THETA > 0:
        # PEAK-AS-BLOCK (novel): append the joint-peak per-expert load as an extra
        # block column so the greedy balances devices across temporal blocks AND the
        # co-spike scenario simultaneously -> placement itself becomes spike-aware,
        # not just the scalar target weight. block_w: (L,E,k) -> (L,E,k+1).
        block_w = np.concatenate([block_w, peak[:, :, None]], axis=2)

    sig = (n_layers, n_experts, n_device, n_exp_per_dev)
    cur = _STATE.get("deploy") if _STATE.get("sig") == sig else None

    candidate = np.zeros((n_layers, n_device, n_exp_per_dev), dtype=np.int64)
    for l in range(n_layers):
        prev = cur[l] if cur is not None else None
        if use_block:
            candidate[l] = _build_block(risk[l], block_w[l], n_device, n_exp_per_dev,
                                        prev, rep_w[l])
        else:
            # EP>BLOCK_MAXDEV (EP256, 2 slots/device): explicit anti-correlation pairing.
            candidate[l] = _build_covmatch(risk[l], hotness[:, l, :], n_device,
                                           n_exp_per_dev, prev, rep_weight=rep_w[l],
                                           drift_a=float(drift_a[l]))

    if cur is None:
        init = _init_deploy_table(n_device, n_experts, n_exp_per_dev)
        for l in range(n_layers):
            candidate[l] = _align(candidate[l], init, place_w[l])
        _STATE["sig"] = sig
        _STATE["deploy"] = candidate.copy()
        return True, np.arange(n_layers, dtype=np.int64), candidate, None

    for l in range(n_layers):
        candidate[l] = _align(candidate[l], cur[l], place_w[l])

    improve = np.array([_par(place_w[l], cur[l]) - _par(place_w[l], candidate[l])
                        for l in range(n_layers)])
    sel = np.where(improve > TAU)[0]
    if sel.size == 0:
        return False, np.array([], dtype=np.int64), candidate, None

    order = sel[np.argsort(improve[sel])[::-1]]
    new_state = cur.copy()
    new_state[order] = candidate[order]
    _STATE["deploy"] = new_state
    return True, order.astype(np.int64), candidate, None
